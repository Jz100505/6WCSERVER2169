function getAboutContent(name) {
    return `${name}, if you want additional details about this activity, go to this site: https://www.tutorialsteacher.com/nodejs/nodejs-tutorials`;
}

module.exports = {
    getAboutContent
};

/*
Your Name: Manaloto, Johnzelle
Date: 16/07/2025
Section: WD - 301
*/