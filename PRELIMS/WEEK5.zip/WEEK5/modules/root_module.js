function getRootContent(name) {
    return `Welcome ${name}. This is an activity about basics of Node.js`;
}
    
module.exports = {
    getRootContent   
};

/*
Your Name: Manaloto, Johnzelle
Date: 16/07/2025
Section: WD - 301
*/