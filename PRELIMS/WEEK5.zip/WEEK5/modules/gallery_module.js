function getGalleryContent() {
    return `This is the Gallery Page`;
}

module.exports = {
    getGalleryContent
};

/*
Your Name: Manaloto, Johnzelle
Date: 16/07/2025
Section: WD - 301
*/