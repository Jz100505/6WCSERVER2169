const ConditionalRendering = {
    data() {
        return {
            seen: true
        }
    }
};

Vue.createApp(ConditionalRendering).mount('#conditional-rendering');