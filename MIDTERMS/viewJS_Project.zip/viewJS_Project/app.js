const app = Vue.createApp({
    data() {
        return {
            title: 'The Ledger',
            author: 'Joseph Esquivel',
            age: 34
        }
    }
});

app.mount('#app');